#ifndef _su_app_version_h_
#define _su_app_version_h_

#define SU_APP_MAJOR_VERSION    1
#define SU_APP_MINOR_VERSION    0
#define SU_APP_REVISION         0
#define SU_APP_MISSION_REV      0
      
#endif