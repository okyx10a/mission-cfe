#ifndef _su_app_events_h_
#define _su_app_events_h_


#define SU_RESERVED_EID              0
#define SU_STARTUP_INF_EID           1 
#define SU_COMMAND_ERR_EID           2
#define SU_COMMANDNOP_INF_EID        3 
#define SU_COMMANDRST_INF_EID        4
#define SU_INVALID_MSGID_ERR_EID     5 
#define SU_LEN_ERR_EID               6 

#endif