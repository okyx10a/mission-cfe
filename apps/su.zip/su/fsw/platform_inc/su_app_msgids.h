#ifndef _su_app_msgids_h_
#define _su_app_msgids_h_

#define SU_APP_CMD_MID              0x1992
#define SU_APP_SEND_HK_MID          0x1993
#define SU_APP_HK_TLM_MID           0x0993

#endif