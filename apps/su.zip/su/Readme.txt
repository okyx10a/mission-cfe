In the software bus header 
1) Set Msg ID: SU_APP_CMD_MID 0x1992
2) Set Cmd ID: 0 for PING
	       1 for INIT
               2 for PING + INIT

If you want to search for definition in sublime text select the function or variable and press F12.
